<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_site_com' );

/** Database username */
define( 'DB_USER', 'wp_user_site' );

/** Database password */
define( 'DB_PASSWORD', 'P@ssw0rd' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'yD$&w~ 4kmOszvaY+# &aMh}:P|upVcC%ZF`1;nt/R1LqsyUXS%O!L/?bx.hJY2x' );
define( 'SECURE_AUTH_KEY',  '#Z$v[PCJIc?MVDLgkVC<eq9(hvyYJdc{525;Gx>IkZT]J)0n_[J:Ec_x8dINZOf ' );
define( 'LOGGED_IN_KEY',    'SwT2nB2>H4x`LyR0r]Zjd]^$A-_e%Q]&DLE~ n.O%fAw[_/EI5(tO bUb X tx_]' );
define( 'NONCE_KEY',        '}p;Vz+&UD.n Z~_6_lK5M~qM)wvl_vqw^X_+pe:0(Im( *d;h>1Fdo(~BuLj).Qd' );
define( 'AUTH_SALT',        'pi:U]EUy~~<+K&P1ff}^$Ojo%^X}18*Fd}&u{&q`QS2;*)q4hEV(7&b|V!C^>ea)' );
define( 'SECURE_AUTH_SALT', '|Z<c={PVl&X5&q@wjJ$<L>c,/GYv?(SzA[eP2OY.Cn,[E e*.b1Wrz,Cjv(etE;?' );
define( 'LOGGED_IN_SALT',   'H]L9@cAtj}+7(n?kUy).pmAwdbO2O*-q.oQKPb[0RWk.i>jUj~{D&&wGgNT@i=p.' );
define( 'NONCE_SALT',       ']9=wJuiUBsnR*ag:Gk{Hu@Z)`(>n@ 5|$eS7dpLzx|IToJIu<u!Ne-i!__6]g[V^' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
